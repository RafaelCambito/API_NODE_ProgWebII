import express from "express"; //Framework para o desenvolvimento de aplicações utilizando o Node e gerenciamento de rotas
import {v4 as uuid} from 'uuid'; //permite gerar id automaticamente e único ao cadastrar o aluno

const app = express();
app.use(express.json());  //permite express receber formato json
const alunos = [];

//Rota para cadastro de aluno - POST
app.post('/alunos', (request, response) => {
    const {nome, sobrenome, email, datanascimento, matricula} = request.body;

    const aluno = {id: uuid(), nome, sobrenome, email, datanascimento, matricula};

    alunos.push({aluno});    
    response.json(aluno);
});

//Rota para buscar aluno cadastrado - GET
app.get('/alunos', (request, response) => {
    response.json(alunos);
});

//Rota para atualizar aluno já cadastrado -PUT
app.put('/alunos/:idAlunos', (request, response) => {
    const {idAluno} = request.params;  //obtendo o id do usuário através dos parâmetros de rota
    const {nome, sobrenome, email, datanascimento, matricula} = request.body; //obter os dados que quero atualizar

    console.log(idAluno);

    const indexAluno = alunos.findIndex((aluno) => aluno.id == idAluno); //procurando o usuario na posição usando o findIndex
    
    alunos[indexAluno] = {...alunos[indexAluno], nome, sobrenome, email, datanascimento, matricula} //passando os novos dados

    response.json(alunos[indexAluno]); //retornando os dados para o front
});


app.listen(4000, () => { console.log ('Servidor Iniciado')});  // log demonstrando se o servidor iniciou corretamente usando porta 4000